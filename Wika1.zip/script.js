document.addEventListener("DOMContentLoaded", () => {
    loadDatabase();
    startCamera();
    document.getElementById("switch-btn")?.addEventListener("click", switchCamera);
    document.getElementById("gallery-btn")?.addEventListener("click", () => document.getElementById("image-input").click());
    document.getElementById("image-input")?.addEventListener("change", handleImageUpload);
    document.getElementById("upload-db-btn")?.addEventListener("change", uploadDatabase);
    document.getElementById("capture-btn")?.addEventListener("click", captureImage);
    document.getElementById("search-btn")?.addEventListener("click", searchWord);
    document.getElementById("search-input")?.addEventListener("keypress", (event) => {
        if (event.key === "Enter") {
            searchWord();
        }
    });
});

function loadDatabase() {
    fetch("database.json")
        .then(response => response.json())
        .then(data => {
            localStorage.setItem("dictionaryData", JSON.stringify(data));
            console.log("Database loaded successfully.");
        })
        .catch(error => console.error("Error loading database:", error));
}

let currentFacingMode = "environment";
let stream = null;

async function startCamera() {
    try {
        const video = document.getElementById("camera-view");
        stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: currentFacingMode, aspectRatio: 4 / 3 }
        });
        video.srcObject = stream;
        video.style.width = "100%";
        video.style.height = "100%";
        video.style.objectFit = "cover";
        video.style.transform = currentFacingMode === "user" ? "scaleX(-1)" : "scaleX(1)";
    } catch (error) {
        console.error("Error accessing camera:", error);
    }
}

async function switchCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
    currentFacingMode = currentFacingMode === "environment" ? "user" : "environment";
    await startCamera(); // Await the camera start

    // Clear displayed result
    let resultDisplay = document.getElementById("scan-result");
    if (resultDisplay) {
        resultDisplay.remove();
    }
}

function captureImage() {
    const video = document.getElementById("camera-view");
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    processImage(canvas);
}

function handleImageUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = function () {
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d");
            canvas.width = img.width;
            canvas.height = img.height;
            context.drawImage(img, 0, 0, canvas.width, canvas.height);
            processImage(canvas);
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function uploadDatabase(event) {
    const file = event.target.files[0];
    if (!file || !file.name.endsWith(".json")) {
        alert("Please upload a valid JSON file.");
        return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
        try {
            const data = JSON.parse(e.target.result);
            localStorage.setItem("dictionaryData", JSON.stringify(data));
            alert("Database uploaded successfully!");
        } catch (error) {
            alert("Invalid JSON file.");
            console.error("Error parsing JSON:", error);
        }
    };
    reader.readAsText(file);
}

function processImage(canvas) {
    Tesseract.recognize(canvas, 'eng', { logger: m => console.log(m) })
        .then(({ data: { text } }) => {
            console.log("Recognized Text:", text);
            searchWordFromImage(text.trim());
        })
        .catch(error => console.error("Error processing image:", error));
}

function searchWord() {
    const query = document.getElementById("search-input").value.toLowerCase().trim();
    searchWordFromImage(query);
}

function searchWordFromImage(word) {
    const dictionaryData = JSON.parse(localStorage.getItem("dictionaryData")) || [];
    const result = dictionaryData.find(entry => entry.word.toLowerCase() === word.toLowerCase());
    let resultDisplay = document.getElementById("scan-result");

    if (!resultDisplay) {
        resultDisplay = document.createElement("div");
        resultDisplay.id = "scan-result";
        resultDisplay.style.position = "absolute";
        resultDisplay.style.top = "11%";
        resultDisplay.style.left = "50%";
        resultDisplay.style.transform = "translateX(-50%)";
        resultDisplay.style.backgroundColor = "rgba(0, 0, 0, 1)";
        resultDisplay.style.color = "white";
        resultDisplay.style.padding = "22%";
        resultDisplay.style.borderRadius = "5px";
        resultDisplay.style.textAlign = "center";
        resultDisplay.style.width = "100%";
        resultDisplay.style.maxWidth = "400px";
        document.body.appendChild(resultDisplay);
    }

    if (result) {
        resultDisplay.innerHTML = `
            <h1><u>${result.word}</u></h1>
            <h3><u>Ingles:</u> ${result.english}</h3>
            <h3><u>Pagbigkas:</u> ${result.phonetic}</h3>
            <h3><u>Bahagi ng Pananalita:</u> ${result.partOfSpeech}</h3>
            <h3><u>Kahulugan:</u><br>${result.definition}</h3>
            <h3><u>Halimbawa:</u><br>${result.example}</h3>
        `;
    } else {
        resultDisplay.innerHTML = `<p class='error'>Walang nahanap na resulta.</p>`;
    }
}